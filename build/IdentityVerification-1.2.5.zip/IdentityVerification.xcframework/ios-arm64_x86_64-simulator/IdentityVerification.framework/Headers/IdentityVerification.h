//
//  IdentityVerification.h
//  IdentityVerification
//
//  Created by Igor Babitski on 26/02/2023.
//

#import <Foundation/Foundation.h>


//! Project version number for IdentityVerification.
FOUNDATION_EXPORT double IdentityVerificationVersionNumber;

//! Project version string for IdentityVerification.
FOUNDATION_EXPORT const unsigned char IdentityVerificationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdentityVerification/PublicHeader.h>


